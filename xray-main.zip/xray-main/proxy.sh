wget https://raw.githubusercontent.com/serverok/squid-proxy-installer/master/squid3-install.sh &&  sudo bash squid3-install.sh
sudo squid-add-user
apt install net-tools 
