bash <(curl -Ls  https://raw.githubusercontent.com/Panhuqusyxh/xray/main/aws2.sh)
